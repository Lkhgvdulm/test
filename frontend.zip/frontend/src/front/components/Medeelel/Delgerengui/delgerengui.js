import React from 'react';
import Delgerengui_end from '../../../container/medee_medeelel/delgerengui_end/delgerengui_end';
import Header from '../../carousel/header/header';

const Delgerengui = () => {
	return (
		<div>
			<Header/>
            <div className='ene shdeee'>
                <Delgerengui_end/>
            </div>
		</div>
	);
};
export default Delgerengui;
