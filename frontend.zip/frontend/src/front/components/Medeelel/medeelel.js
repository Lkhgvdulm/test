import React from 'react';
import { Link } from 'react-router-dom';
import { FacebookEmbed } from 'react-social-media-embed';
import './medeelel.css';

const Medeelel = () => {
	return (
		<div>
			<div className="header_medeee">
				<div className="container_medee">
					<h3>МЭДЭЭ, МЭДЭЭЛЭЛ</h3>
					<div className="line_medee">
						<div className="line_8"></div>
					</div>
				</div>
			</div>
			<div className="Newss">
				<div className="News">
					<div className="Medee_list">
						<div className="Medee_list_cards">
							<img src="https://www.premiumgroup.mn/wp-content/uploads/2021/06/1.jpg"></img>
							<div className="text">
								<h3>
									<a href="https://www.premiumgroup.mn/%d0%b0-%d0%b3%d0%b0%d0%bd%d1%85%d1%83%d1%8f%d0%b3-cu-%d0%bc%d0%be%d0%bd%d0%b3%d0%be%d0%bb-%d0%b1%d0%b8%d0%b7%d0%bd%d0%b5%d1%81-%d1%85%d3%a9%d0%b3%d0%b6%d0%b8%d1%85-%d0%bd%d0%b8%d0%b9%d0%b3%d0%bc/">
										А.ГАНХУЯГ: “CU МОНГОЛ” БИЗНЕС ХӨГЖИХ НИЙГМИЙН ДЭД БҮТЭЦ
										БОЛНО
									</a>
								</h3>
								<br></br>
								<div className="date">2022.03.17</div>
								<br></br>
								<div className="more">
									<Link to="/delgerengui">Дэлгэрэнгүй</Link>
								</div>
							</div>
						</div>
						{/* <div className="Medee_list_cards">
							<img src="https://www.premiumgroup.mn/wp-content/uploads/2021/06/1.jpg"></img>
							<div className="text">
								<h3>
									<a href='https://www.premiumgroup.mn/%d0%b0-%d0%b3%d0%b0%d0%bd%d1%85%d1%83%d1%8f%d0%b3-cu-%d0%bc%d0%be%d0%bd%d0%b3%d0%be%d0%bb-%d0%b1%d0%b8%d0%b7%d0%bd%d0%b5%d1%81-%d1%85%d3%a9%d0%b3%d0%b6%d0%b8%d1%85-%d0%bd%d0%b8%d0%b9%d0%b3%d0%bc/'>
									А.ГАНХУЯГ: “CU МОНГОЛ” БИЗНЕС ХӨГЖИХ НИЙГМИЙН ДЭД БҮТЭЦ БОЛНО
									</a>
								</h3><br></br>
								<div className='date'>2022.03.17</div><br></br>
								<div className='more'>
								<a href='https://www.premiumgroup.mn/%d0%b0-%d0%b3%d0%b0%d0%bd%d1%85%d1%83%d1%8f%d0%b3-cu-%d0%bc%d0%be%d0%bd%d0%b3%d0%be%d0%bb-%d0%b1%d0%b8%d0%b7%d0%bd%d0%b5%d1%81-%d1%85%d3%a9%d0%b3%d0%b6%d0%b8%d1%85-%d0%bd%d0%b8%d0%b9%d0%b3%d0%bc/'>
								Дэлгэрэнгүй
								</a>
								</div>
							</div>
						</div> */}
						{/* <div className="Medee_list_cards">
							<img src="https://www.premiumgroup.mn/wp-content/uploads/2021/06/1.jpg"></img>
							<div className="text">
								<h3>
									<a href='https://www.premiumgroup.mn/%d0%b0-%d0%b3%d0%b0%d0%bd%d1%85%d1%83%d1%8f%d0%b3-cu-%d0%bc%d0%be%d0%bd%d0%b3%d0%be%d0%bb-%d0%b1%d0%b8%d0%b7%d0%bd%d0%b5%d1%81-%d1%85%d3%a9%d0%b3%d0%b6%d0%b8%d1%85-%d0%bd%d0%b8%d0%b9%d0%b3%d0%bc/'>
									А.ГАНХУЯГ: “CU МОНГОЛ” БИЗНЕС ХӨГЖИХ НИЙГМИЙН ДЭД БҮТЭЦ БОЛНО
									</a>
								</h3><br></br>
								<div className='date'>2022.03.17</div><br></br>
								<div className='more'>
								<a href='https://www.premiumgroup.mn/%d0%b0-%d0%b3%d0%b0%d0%bd%d1%85%d1%83%d1%8f%d0%b3-cu-%d0%bc%d0%be%d0%bd%d0%b3%d0%be%d0%bb-%d0%b1%d0%b8%d0%b7%d0%bd%d0%b5%d1%81-%d1%85%d3%a9%d0%b3%d0%b6%d0%b8%d1%85-%d0%bd%d0%b8%d0%b9%d0%b3%d0%bc/'>
								Дэлгэрэнгүй
								</a>
								</div>
							</div>
						</div>
						<div className="Medee_list_cards">
							<img src="https://www.premiumgroup.mn/wp-content/uploads/2021/06/1.jpg"></img>
							<div className="text">
								<h3>
									<a href='https://www.premiumgroup.mn/%d0%b0-%d0%b3%d0%b0%d0%bd%d1%85%d1%83%d1%8f%d0%b3-cu-%d0%bc%d0%be%d0%bd%d0%b3%d0%be%d0%bb-%d0%b1%d0%b8%d0%b7%d0%bd%d0%b5%d1%81-%d1%85%d3%a9%d0%b3%d0%b6%d0%b8%d1%85-%d0%bd%d0%b8%d0%b9%d0%b3%d0%bc/'>
									А.ГАНХУЯГ: “CU МОНГОЛ” БИЗНЕС ХӨГЖИХ НИЙГМИЙН ДЭД БҮТЭЦ БОЛНО
									</a>
								</h3><br></br>
								<div className='date'>2022.03.17</div><br></br>
								<div className='more'>
								<a href='https://www.premiumgroup.mn/%d0%b0-%d0%b3%d0%b0%d0%bd%d1%85%d1%83%d1%8f%d0%b3-cu-%d0%bc%d0%be%d0%bd%d0%b3%d0%be%d0%bb-%d0%b1%d0%b8%d0%b7%d0%bd%d0%b5%d1%81-%d1%85%d3%a9%d0%b3%d0%b6%d0%b8%d1%85-%d0%bd%d0%b8%d0%b9%d0%b3%d0%bc/'>
								Дэлгэрэнгүй
								</a>
								</div>
							</div>
						</div> */}
					</div>

					<div className="Medee_facebook">
						<FacebookEmbed
							url="https://www.facebook.com/urjikhtavilgiindelguur/photos/pcb.216144357487276/216056360829409/"
							width={300}
						/>
					</div>
				</div>
			</div>
		</div>
	);
};
export default Medeelel;
