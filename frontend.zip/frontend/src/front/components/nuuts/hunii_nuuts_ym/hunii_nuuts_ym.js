import React, { useEffect, useState } from 'react';
import { CDNURL, url } from '../../../../utils/url';
import axios from 'axios';
import './hunii_nuuts_ym.css';

const Hunii_nuuts_ym = () => {
	const [workplace, setWorkplace] = useState([]);
	useEffect(() => {
		const getWorkplace = async () => {
			const { data } = await axios.get(`${url}/resource`);
			setWorkplace(data.data);
		};
		getWorkplace();
	}, []);
	return (
		<div>
			<div>
				<div className="h-container">
					<div className="h-header">
						<p>ХҮНИЙ НӨӨЦ</p>
						<div class="line-menu">
							<div class="line-h"></div>
						</div>
					</div>
				</div>
				<div className="Zzz">
					{workplace.map((row) => (
						<div className="Zzz1">
							<img src={`${CDNURL}/${row.avatar}`} alt="/" />
						</div>
					))}
					<div className="Zzz2">
						<div>
							{workplace.map((row) => (
								<h2>{row.name}</h2>
							))}
						</div>

						<h2>БИДНИЙ ЗОРИЛТ</h2>
						<ul className="list">
							<li>
								Групп нь ажилтны ур чадвар, ажлын үр дүнг харгалзсан хөдөлмөр
								эрхлэлтийг тэгш боломжоор хангаж хариуцлагатай ажил олгогч байх
							</li>
							<li>
								Группийн хүний нөөцийг чадварлаг боловсон хүчнээр бэхжүүлж,
								тэднийг сурч хөгжих таатай нөхцөлөөр хангах
							</li>
							<li>
								Групп, ажилтан хамтдаа хөгжин дэвших суралцагч байгууллага байх
							</li>
							<li>
								Ажилтан нэг бүрийн бүтээмжийг өсгөх замаар бизнесийн ашигт
								ажиллагааг нэмэгдүүлэх
							</li>
							<li>
								Ажилтан нэг бүрийн бүтээмжийг өсгөх замаар бизнесийн ашигт
								ажиллагааг нэмэгдүүлэх
							</li>
							<li>
								Ажилтан нэг бүрийн бүтээмжийг өсгөх замаар бизнесийн ашигт
								ажиллагааг нэмэгдүүлэх
							</li>
							<li>
								Ажилтан нэг бүрийн бүтээмжийг өсгөх замаар бизнесийн ашигт
								ажиллагааг нэмэгдүүлэх
							</li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	);
};
export default Hunii_nuuts_ym;
