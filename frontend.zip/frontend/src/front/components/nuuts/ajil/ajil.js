import React from 'react';
import './ajil.css';

const Ajil = () => {
	return (
		<div>
			<div className="container_job">
				<div className="header_job">
					<h1 className='nas'>НЭЭЛТТЭЙ АЖЛЫН БАЙР</h1>
					<div className="line_menu_job">
						<div className="line_job"></div>
					</div>
				</div>
			</div>
			<div className="neg_tom">
				<div className="on_sar">
					<div className="tailbar_heseg">
						<p>2023.03.09</p>
					</div>
					<div className="line_bogino">
						<div className="line"></div>
					</div>
					<div className="tailbar_h">
						<div className="zar">
							<p>Дотоод удирдлага зохицуулалтын ажилтан</p>
							<h3>
								Компанийн бизнесийн өдөр тутмын үйл ажиллагаатай холбогдох
								баримт бичгүүдийг бүрдүүлэх, шаардлагатай баримт бичгүүдийг
								орчуулах; Хурлын бэлтгэл хангах, шаардлагатай зохион
								байгуулалтыг хийх
							</h3>
						</div>
					</div>
				</div>
				{/* <div className="on_sar">
					<div className="tailbar_heseg">
						<p>2023.03.09</p>
					</div>
					<div className="line_bogino">
						<div className="line"></div>
					</div>
					<div className="tailbar_h">
						<div className="zar">
							<p>Дотоод удирдлага зохицуулалтын ажилтан</p>
							<h3>
								Компанийн бизнесийн өдөр тутмын үйл ажиллагаатай холбогдох
								баримт бичгүүдийг бүрдүүлэх, шаардлагатай баримт бичгүүдийг
								орчуулах; Хурлын бэлтгэл хангах, шаардлагатай зохион
								байгуулалтыг хийх
							</h3>
						</div>
					</div>
				</div> */}
			</div>
		</div>
	);
};
export default Ajil;
