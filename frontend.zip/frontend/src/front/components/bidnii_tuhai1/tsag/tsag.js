import React from "react";
import './tsag.css';

const Tsag =() => {
    return(
        <div>
            <div className="container-h">
                <div className="zurag">
                   <div className="m">
                        
                   </div>
                </div>
            </div>
        </div>
    )
}
export default Tsag