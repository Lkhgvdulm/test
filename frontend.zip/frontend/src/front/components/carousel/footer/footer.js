import React from 'react';
import './footer.css';

const Footer = () => {
	return (
		<div class="f-bottom">
			<h1 class="roboto">Бүх эрх хуулиар хамгаалагдсан</h1>
		</div>
	);
};
export default Footer;
