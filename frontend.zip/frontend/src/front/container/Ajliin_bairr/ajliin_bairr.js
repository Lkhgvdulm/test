import React from "react";
import Ajliin_bair from "../../components/banner/hunii_nuuts_y/Ajliin_bair/ajliin_bair";
import './ajliin_bairr.css';

const Ajliin_bairr =() => {
    return(
        <div>
            <Ajliin_bair/>
        </div>
    )
}
export default Ajliin_bairr