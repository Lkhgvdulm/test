import React from "react";
import Header from "../../components/carousel/header/header";
import Medeelel from "../../components/Medeelel/medeelel";
import Footer from "../../components/carousel/footer/footer";
import './medee_medeelel.css';

const Medee_medeelel =() => {
    return(
        <div className="me"> 
            <Header/>
            <Medeelel/>
            <Footer/>
        </div>
    )
}
export default Medee_medeelel