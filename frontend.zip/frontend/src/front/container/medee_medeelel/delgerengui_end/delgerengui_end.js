import React from 'react';
import './delgerengui_end.css';

const Delgerengui_end = () => {
	return (
		<div>
			<div className="container_delgerengui">
				<div className="header_delgerengui">
					<h3>А.ГАНХУЯГ: “CU МОНГОЛ” БИЗНЕС ХӨГЖИХ НИЙГМИЙН ДЭД БҮТЭЦ БОЛНО</h3>
                    <div className='shugam'>
                        <div className='shugam_delgerengui'>
                        </div>
                    </div>
				</div>
			</div>
		</div>
	);
};
export default Delgerengui_end;
