export const CDNURL = `http://localhost:3001`;
export const CDNWEBURL = `http://localhost:3000`;
export const url = `http://localhost:3001/api`;
